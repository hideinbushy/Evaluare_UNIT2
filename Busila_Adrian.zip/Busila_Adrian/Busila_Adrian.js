var slide_count = 0;

function slideshow()
{
	var i;
	var img = document.getElementsByClassName("slide");
	for(i=0;i<img.length;i++)
	{
		img[i].style.display="none";
	}
	slide_count++;
	if(slide_count>img.length)
	{
		slide_count=1;
	}
	img[slide_count-1].style.display="block";
	setTimeout(slideshow,3000);
}
